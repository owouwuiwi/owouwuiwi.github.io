#!/usr/bin/env python3
"""Render the same English Markdown guides as responsive static pages."""
import html
import re
import shutil
from pathlib import Path
import markdown

ROOT = Path(__file__).resolve().parents[1]


def render():
    target = ROOT / 'website'
    pages = [('README.md', 'guide/index.html', 'Quick start'),
             ('docs/REFERENCE.md', 'reference/index.html', 'Technical reference'),
             ('docs/CHECKLIST.md', 'checklist/index.html', 'Release checklist')]
    routes = {'docs/REFERENCE.md': '/example/reference/', 'docs/CHECKLIST.md': '/example/checklist/',
              '../README.md': '/example/guide/', '../README.md#': '/example/guide/#',
              'REFERENCE.md': '/example/reference/', 'CHECKLIST.md': '/example/checklist/',
              'website/ASSETS.md': '/example/ASSETS.md'}
    for source, destination, title in pages:
        text = (ROOT / source).read_text(encoding='utf-8')
        for old, new in routes.items():
            text = text.replace('](' + old + ')', '](' + new + ')').replace('](' + old + '#', '](' + new + '#')
        body = markdown.markdown(text, extensions=['fenced_code', 'tables', 'toc'])
        body = re.sub(r'<a href="(https?://[^"]+)"', r'<a rel="noopener" href="\1"', body)
        document = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + html.escape(title) + ' · Nyanime developers</title><link rel="stylesheet" href="/example/style.css"><style>article{max-width:880px}h2{margin-top:2em}pre{padding:18px;border-radius:14px;background:#202637;overflow:auto;font-size:14px}code{font-size:.9em}table{display:block;overflow:auto;border-collapse:collapse}th,td{padding:12px;border-bottom:1px solid #394052;text-align:left;vertical-align:top}nav{display:flex;flex-wrap:wrap;gap:18px}.skip{position:absolute;left:-9999px}.skip:focus{left:12px}</style></head><body><a class="skip" href="#content">Skip to content</a><header><a href="/example/">◇ NYANIME DEVELOPERS</a><nav><a href="/example/guide/">Quick start</a><a href="/example/reference/">Reference</a><a href="/example/checklist/">Checklist</a></nav></header><main id="content"><article>' + body + '</article></main><footer>English developer documentation · <a href="/example/downloads/placeholder-extension-kit.zip">Download kit</a> · <a href="https://github.com/owouwuiwi/nyanime">Application source</a></footer></body></html>'
        file = target / destination
        file.parent.mkdir(exist_ok=True)
        file.write_text(document, encoding='utf-8')
    shutil.copyfile(ROOT / 'README.md', target / 'README.md')
    index = target / 'index.html'
    text = index.read_text(encoding='utf-8').replace('href="README.md"', 'href="guide/"')
    text = text.replace('Five-step guide</a>', 'Five-step guide</a> · <a href="reference/">Technical reference</a>')
    index.write_text(text, encoding='utf-8')
    print('Rendered quick start, technical reference and release checklist.')


if __name__ == '__main__':
    render()
